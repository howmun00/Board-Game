class GameLogic:
    print("Game Logic Object Created")
    # TODO add code here to manage the logic of your game
