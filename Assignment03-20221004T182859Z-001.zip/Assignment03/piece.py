class Piece(object):
    NoPiece = 0
    White = 1
    Black = 2
